import olpcgames

class FoodForce2Activity(olpcgames.PyGameActivity):
    """An example of using a Pygame game as a Sugar activity."""
    
    game_name = 'FoodForce2'
    # Alternately, 
    #game_name = 'mygame:mymainfunction'
    game_title = 'FoodForce2'
    game_size = (1200, 845)
